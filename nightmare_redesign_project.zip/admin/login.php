<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Login</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-dark text-white">

<div class="container py-5">
    <div class="row justify-content-center">

        <div class="col-md-5">
            <div class="card bg-black border-secondary">
                <div class="card-body p-4">

                    <h2 class="mb-4">Admin Login</h2>

                    <form method="POST">

                        <div class="mb-3">
                            <label>Username</label>
                            <input type="text" class="form-control">
                        </div>

                        <div class="mb-3">
                            <label>Password</label>
                            <input type="password" class="form-control">
                        </div>

                        <button class="btn btn-primary w-100">
                            Login
                        </button>

                    </form>

                </div>
            </div>
        </div>

    </div>
</div>

</body>
</html>
