<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="bg-dark text-white">

<div class="container py-5">

    <h1 class="mb-4">Admin Dashboard</h1>

    <div class="row g-4">

        <div class="col-md-4">
            <div class="card bg-black border-secondary">
                <div class="card-body">
                    <h5>Total Members</h5>
                    <h2>2542</h2>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card bg-black border-secondary">
                <div class="card-body">
                    <h5>Leadership Roles</h5>
                    <h2>18</h2>
                </div>
            </div>
        </div>

    </div>

</div>

</body>
</html>
