<?php

require '../../config/database.php';

header('Content-Type: application/json');

$db = new Database();
$conn = $db->connect();

$stmt = $conn->prepare("
    INSERT INTO leadership
    (server_name, role_name, member_name, squad_name)
    VALUES(?,?,?,?)
");

$stmt->execute([
    $_POST['server_name'],
    $_POST['role_name'],
    $_POST['member_name'],
    $_POST['squad_name']
]);

echo json_encode([
    'success' => true,
    'message' => 'Leadership added'
]);
?>
