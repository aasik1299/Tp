<?php

require '../config/database.php';

header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);

$db = new Database();
$conn = $db->connect();

$stmt = $conn->prepare("
    UPDATE leadership
    SET member_name=?, updated_at=NOW()
    WHERE id=?
");

$stmt->execute([
    $data['member_name'],
    $data['id']
]);

echo json_encode([
    'success' => true
]);
?>
