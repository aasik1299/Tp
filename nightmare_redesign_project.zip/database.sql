CREATE DATABASE nightmare;

USE nightmare;

CREATE TABLE admins(
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100),
    password VARCHAR(255),
    role VARCHAR(50)
);

CREATE TABLE leadership(
    id INT AUTO_INCREMENT PRIMARY KEY,
    server_name VARCHAR(100),
    role_name VARCHAR(100),
    member_name VARCHAR(100),
    squad_name VARCHAR(100),
    image VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE family_members(
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100),
    role VARCHAR(100),
    server_name VARCHAR(100),
    image VARCHAR(255),
    joined_date DATE
);
