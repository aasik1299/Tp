
# Nightmare Community Redesign

Modern full-stack Bootstrap 5 + PHP + MySQL architecture.

## Features
- Bootstrap 5 responsive UI
- PHP REST APIs
- Admin dashboard
- Authentication system
- CRUD operations
- Dynamic leadership system
- Image uploads
- MySQL database
- Secure architecture

## Setup
1. Import database.sql
2. Configure config/database.php
3. Run on XAMPP/Laragon
4. Open /admin/login.php
