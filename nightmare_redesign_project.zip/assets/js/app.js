document.addEventListener("DOMContentLoaded", () => {
    console.log("Nightmare Community Loaded");
});
