<?php include 'components/navbar.php'; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Nightmare Community</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

<section class="hero">
    <div class="container">
        <div class="row align-items-center">

            <div class="col-lg-6">
                <span class="badge bg-danger mb-3">Grand RP Community</span>

                <h1 class="display-2 fw-bold">
                    Enter The Nightmare
                </h1>

                <p class="lead text-light opacity-75">
                    Modern community platform rebuilt with Bootstrap 5 and PHP.
                </p>

                <div class="d-flex gap-3 mt-4">
                    <a href="#" class="btn btn-primary btn-lg">
                        Join Community
                    </a>

                    <a href="#" class="btn btn-outline-light btn-lg">
                        Leadership
                    </a>
                </div>
            </div>

            <div class="col-lg-6">
                <div class="glass-card">
                    <h3>Modern Dashboard Ready</h3>
                    <p>Dynamic leadership, APIs, admin panel and CMS architecture included.</p>
                </div>
            </div>

        </div>
    </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/app.js"></script>

</body>
</html>
